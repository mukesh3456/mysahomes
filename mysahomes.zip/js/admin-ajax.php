
<!-- saved from url=(0063)https://demo.goodlayers.com/hotelmaster/wp-admin/admin-ajax.php -->
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"></head><body>0</body></html>